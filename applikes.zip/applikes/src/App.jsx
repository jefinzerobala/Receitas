import {Post} from "./Post"

export function App() {
   return ( 
     <div>

    <Post author="Machado de Assis" 
    coment="Lorem ipsum dolor, 
    sit amet consectetur adipisicing elit. Quae praesentium libero repellat saepe 
    nobis maxime neque blanditiis labore veritatis, minima, magnam necessitatibus 
    odit quibusdam dolor aperiam sapiente natus cupiditate laudantium."/>

  <Post author="Ricardo Eletro" 
    coment="Lorem ipsum dolor, 
    sit amet consectetur adipisicing elit. Quae praesentium libero repellat saepe 
    nobis maxime neque blanditiis labore veritatis, minima, magnam necessitatibus 
    odit quibusdam dolor aperiam sapiente natus cupiditate laudantium."/>

  <Post author="Maria do Rosário" 
    coment="Lorem ipsum dolor, 
    sit amet consectetur adipisicing elit. Quae praesentium libero repellat saepe 
    nobis maxime neque blanditiis labore veritatis, minima, magnam necessitatibus 
    odit quibusdam dolor aperiam sapiente natus cupiditate laudantium."/>

  <Post author="Daniel Alves" 
    coment="Lorem ipsum dolor, 
    sit amet consectetur adipisicing elit. Quae praesentium libero repellat saepe 
    nobis maxime neque blanditiis labore veritatis, minima, magnam necessitatibus 
    odit quibusdam dolor aperiam sapiente natus cupiditate laudantium."/>

    </div>
  )
}

export default App
