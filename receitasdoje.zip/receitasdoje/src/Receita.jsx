export function Receita(prop){
    return  <div>
        <strong>{prop.t}</strong>
        <p>{prop.r}</p>
    </div>
}

