import {Receita} from "./Receita"

export function App() {
 

  return (
    <Receita 
    t="Piroca Gourmet Sabor Bacon"
    r="Ingredientes: 
    45 gramas de pipoca estourada
    30 ml de água
    15 ml de vinagre
    1/2 colher (chá) de sal
    140 g de açúcar cristal
    60 g de isomalte
    1 colher (café) rasa de bicarbonato
    80 g de bacon frito e triturado
    100 g de farofa temperada pronta
    
    Modo de Preparo:
    
    Fritar o Bacon até ficar bem torradinho. Deixar escorrer em um papel toalha por 3 horas. 
    Reserve. Num pote de aproximadamente 5 litros que tenha tampa coloque a farofa e reserve. 
    Na panela, colocar: a água, o vinagre, o sal, o açúcar e o isomalte. Misturar os ingredientes 
    até o açúcar derreter e, após, não mexer mais. Deixe no fogo até atingir 145 graus, 
    ou até ver o ponto no copo com água (pingar caramelo num copo com água, pegar ele de dentro da água e morder no último dente. 
    O ponto é quando não gruda mais no dente). Nesse momento adicionar bicarbonato, abaixar o fogo, mexer rápido e adicionar as pipocas e o bacon.
    Envolver as pipocas no caramelo até estarem todas homogêneas. Desligar o fogo nesse momento. 
    Virar as pipocas já caramelizadas dentro do pote com a farofa de bacon. Tampar e chacoalhar até as pipocas desgrudarem por completo. Aguarde esfriar para sentir a crocância."/>
  )
}


